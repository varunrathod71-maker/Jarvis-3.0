package com.varun.jarviscontrol;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.provider.Settings;
import android.speech.RecognizerIntent;
import android.speech.tts.TextToSpeech;
import android.graphics.Color;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.view.Gravity;
import android.view.View;
import android.view.inputmethod.InputMethodManager;
import android.content.Context;
import android.widget.*;
import java.util.ArrayList;
import java.util.Locale;

public class MainActivity extends Activity {
    private static final int SPEECH_REQUEST = 71;
    private TextToSpeech tts;
    private JarvisBrain brain;
    private Button sendButton;
    private boolean ttsReady = false;
    private EditText commandInput;
    private TextView status, conversation;
    private LinearLayout root;
    private final int BG=Color.rgb(5,11,20), PANEL=Color.rgb(12,25,41), CYAN=Color.rgb(40,210,255), MUTED=Color.rgb(143,174,196), WHITE=Color.rgb(230,246,255);
    @Override public void onCreate(Bundle state) { super.onCreate(state); getWindow().setStatusBarColor(BG); getWindow().setNavigationBarColor(BG); brain=new JarvisBrain(this); initVoice(); buildUi(); }

    private void initVoice() {
        tts = new TextToSpeech(this, result -> {
            if (result == TextToSpeech.SUCCESS) {
                int lang = tts.setLanguage(Locale.US);
                ttsReady = lang != TextToSpeech.LANG_MISSING_DATA && lang != TextToSpeech.LANG_NOT_SUPPORTED;
                if (ttsReady) speak("JARVIS online. Voice response system ready.");
            }
        });
    }

    private void speak(String message) {
        if (ttsReady && message != null && !message.trim().isEmpty()) {
            tts.speak(message, TextToSpeech.QUEUE_FLUSH, null, "jarvis_reply");
        }
    }

    @Override protected void onDestroy() {
        if (tts != null) { tts.stop(); tts.shutdown(); }
        super.onDestroy();
    }

    private void buildUi() {
        ScrollView scroll = new ScrollView(this);
        scroll.setFillViewport(true);
        scroll.setBackgroundColor(BG);
        scroll.setVerticalScrollBarEnabled(false);

        root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setPadding(dp(18), dp(16), dp(18), dp(24));
        scroll.addView(root, new ScrollView.LayoutParams(-1, -2));

        // Compact header: brand and a small system status, not a row of cards.
        LinearLayout header = new LinearLayout(this);
        header.setGravity(Gravity.CENTER_VERTICAL);
        TextView brand = text("JARVIS", 25, WHITE, true);
        brand.setLetterSpacing(.16f);
        header.addView(brand, new LinearLayout.LayoutParams(0, -2, 1));
        TextView live = text("● ONLINE", 10, CYAN, true);
        live.setPadding(dp(10), dp(7), dp(10), dp(7));
        live.setBackground(shape(Color.rgb(8, 31, 45), Color.rgb(26, 111, 142), dp(20)));
        header.addView(live);
        root.addView(header);
        TextView tagline = text("PERSONAL INTELLIGENCE SYSTEM", 10, MUTED, true);
        tagline.setLetterSpacing(.12f);
        tagline.setPadding(0, dp(3), 0, dp(12));
        root.addView(tagline);

        // One dominant visual anchor: a real custom-drawn reactor, not a Unicode symbol.
        LinearLayout hero = panel();
        hero.setGravity(Gravity.CENTER);
        hero.setPadding(dp(12), dp(14), dp(12), dp(16));
        ReactorView reactor = new ReactorView(this);
        LinearLayout.LayoutParams reactorParams = new LinearLayout.LayoutParams(dp(184), dp(184));
        reactorParams.gravity = Gravity.CENTER;
        hero.addView(reactor, reactorParams);
        TextView coreTitle = text("J.A.R.V.I.S. CORE", 13, WHITE, true);
        coreTitle.setGravity(Gravity.CENTER);
        coreTitle.setLetterSpacing(.14f);
        hero.addView(coreTitle, lp(-1, -2, 0, dp(4), 0, 0));
        TextView coreSub = text("READY WHEN YOU ARE", 10, CYAN, true);
        coreSub.setGravity(Gravity.CENTER);
        coreSub.setPadding(0, dp(5), 0, 0);
        hero.addView(coreSub);
        addPanel(hero, dp(4));

        // Primary action is visually dominant and clearly labelled.
        Button voice = button("◉   TALK TO JARVIS", true);
        root.addView(voice, lp(-1, dp(54), 0, dp(12), 0, 0));
        voice.setOnClickListener(v -> listen());
        TextView voiceHint = text("Tap to speak  ·  or type a command below", 11, MUTED, false);
        voiceHint.setGravity(Gravity.CENTER);
        voiceHint.setPadding(0, dp(7), 0, dp(6));
        root.addView(voiceHint);

        section("COMMAND", "Ask naturally or enter a supported phone action.");
        commandInput = new EditText(this);
        commandInput.setTextColor(WHITE);
        commandInput.setHintTextColor(Color.rgb(104, 137, 158));
        commandInput.setTextSize(14);
        commandInput.setSingleLine(false);
        commandInput.setMinLines(2);
        commandInput.setMaxLines(4);
        commandInput.setGravity(Gravity.TOP | Gravity.START);
        commandInput.setPadding(dp(14), dp(13), dp(14), dp(13));
        commandInput.setHint("Try: open YouTube, go home, or ask a question…");
        commandInput.setBackground(shape(Color.rgb(8, 19, 32), Color.rgb(29, 78, 101), dp(14)));
        root.addView(commandInput, lp(-1, -2, 0, dp(7), 0, 0));
        sendButton = button("RUN COMMAND   ↗", true);
        root.addView(sendButton, lp(-1, dp(48), 0, dp(8), 0, 0));
        sendButton.setOnClickListener(v -> {
            ((InputMethodManager) getSystemService(Context.INPUT_METHOD_SERVICE))
                    .hideSoftInputFromWindow(commandInput.getWindowToken(), 0);
            runCommand(commandInput.getText().toString());
        });

        // Compact 2x2 icon grid with equal widths and clear labels.
        section("QUICK CONTROLS", "Common phone actions");
        LinearLayout row1 = new LinearLayout(this);
        row1.setOrientation(LinearLayout.HORIZONTAL);
        addQuick(row1, "⌂", "HOME", "home");
        addQuick(row1, "↶", "BACK", "back");
        root.addView(row1);
        LinearLayout row2 = new LinearLayout(this);
        row2.setOrientation(LinearLayout.HORIZONTAL);
        addQuick(row2, "▤", "NOTIFICATIONS", "notifications");
        addQuick(row2, "☼", "QUICK SETTINGS", "quick settings");
        root.addView(row2);

        section("CONNECTED APPS", "Launch an app or search YouTube.");
        LinearLayout apps = new LinearLayout(this);
        apps.setOrientation(LinearLayout.HORIZONTAL);
        addQuick(apps, "▶", "YOUTUBE", "open youtube");
        addQuick(apps, "✉", "GMAIL", "open gmail");
        root.addView(apps);
        LinearLayout apps2 = new LinearLayout(this);
        apps2.setOrientation(LinearLayout.HORIZONTAL);
        addQuick(apps2, "➤", "TELEGRAM", "open telegram");
        addQuick(apps2, "◉", "DISCORD", "open discord");
        root.addView(apps2);

        section("ACTIVITY", "Replies and command results");
        LinearLayout chat = panel();
        chat.setPadding(dp(14), dp(13), dp(14), dp(13));
        TextView chatLabel = text("JARVIS  /  CONSOLE", 10, CYAN, true);
        chatLabel.setLetterSpacing(.10f);
        chat.addView(chatLabel);
        conversation = text("System ready. Local commands work without an AI key. Connect an API provider in AI SETUP for natural-language answers.", 13, WHITE, false);
        conversation.setPadding(0, dp(8), 0, dp(8));
        chat.addView(conversation);
        status = text("● IDLE", 10, MUTED, true);
        chat.addView(status);
        addPanel(chat, dp(6));

        Button setup = button("⚙   CONNECT AI BRAIN", false);
        root.addView(setup, lp(-1, dp(46), 0, dp(12), 0, 0));
        setup.setOnClickListener(v -> showBrainSetup());
        Button accessibility = button("PHONE CONTROL PERMISSIONS", false);
        root.addView(accessibility, lp(-1, dp(46), 0, dp(7), 0, 0));
        accessibility.setOnClickListener(v -> startActivity(new Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS)));

        TextView foot = text("PRIVATE BY DESIGN  ·  PERMISSIONS REQUIRED", 9, MUTED, true);
        foot.setGravity(Gravity.CENTER);
        foot.setPadding(0, dp(16), 0, 0);
        root.addView(foot);
        setContentView(scroll);
    }

    /** Static, scalable HUD reactor drawn with Canvas; no image assets or external libraries. */
    private final class ReactorView extends View {
        private final android.graphics.Paint paint = new android.graphics.Paint(android.graphics.Paint.ANTI_ALIAS_FLAG);
        private final android.graphics.RectF oval = new android.graphics.RectF();
        ReactorView(Context context) { super(context); setLayerType(View.LAYER_TYPE_SOFTWARE, null); }
        @Override protected void onDraw(android.graphics.Canvas canvas) {
            super.onDraw(canvas);
            float cx = getWidth() / 2f, cy = getHeight() / 2f;
            float radius = Math.min(getWidth(), getHeight()) * .43f;
            paint.setStyle(android.graphics.Paint.Style.STROKE);
            paint.setStrokeWidth(dp(1));
            paint.setColor(Color.rgb(19, 79, 105));
            canvas.drawCircle(cx, cy, radius, paint);
            paint.setColor(CYAN);
            paint.setStrokeWidth(dp(2));
            paint.setStrokeCap(android.graphics.Paint.Cap.ROUND);
            oval.set(cx-radius*.91f, cy-radius*.91f, cx+radius*.91f, cy+radius*.91f);
            canvas.drawArc(oval, 205, 92, false, paint);
            canvas.drawArc(oval, 25, 68, false, paint);
            paint.setStrokeWidth(dp(1));
            paint.setColor(Color.rgb(28, 110, 139));
            canvas.drawCircle(cx, cy, radius*.72f, paint);
            paint.setColor(Color.rgb(18, 56, 78));
            paint.setStyle(android.graphics.Paint.Style.FILL);
            canvas.drawCircle(cx, cy, radius*.58f, paint);
            paint.setStyle(android.graphics.Paint.Style.STROKE);
            paint.setColor(CYAN);
            paint.setStrokeWidth((int)dp(1));
            canvas.drawCircle(cx, cy, radius*.48f, paint);
            paint.setStyle(android.graphics.Paint.Style.FILL);
            paint.setColor(Color.rgb(108, 235, 255));
            paint.setShadowLayer(dp(14), 0, 0, CYAN);
            canvas.drawCircle(cx, cy, radius*.19f, paint);
            paint.clearShadowLayer();
            paint.setColor(Color.WHITE);
            paint.setTextAlign(android.graphics.Paint.Align.CENTER);
            paint.setTypeface(Typeface.create("sans-serif-medium", Typeface.BOLD));
            paint.setTextSize(dp(9));
            canvas.drawText("AI", cx, cy + radius*.035f, paint);
            paint.setColor(Color.rgb(77, 174, 204));
            paint.setTextSize(dp(8));
            canvas.drawText("SYSTEM ONLINE", cx, cy + radius*1.18f, paint);
        }
    }

    private void section(String title,String desc){ TextView t=text(title,12,CYAN,true); t.setLetterSpacing(.12f); t.setPadding(dp(2),dp(19),0,dp(4)); root.addView(t); TextView d=text(desc,11,MUTED,false); d.setPadding(dp(2),0,0,dp(5)); root.addView(d); }
    private LinearLayout panel(){ LinearLayout p=new LinearLayout(this); p.setOrientation(LinearLayout.VERTICAL); p.setBackground(shape(PANEL,Color.rgb(24,82,111),dp(16))); return p; }
    private void addPanel(View v,int top){ root.addView(v,lp(-1,-2,0,top,0,0)); }
    private void addQuick(LinearLayout row,String icon,String label,String command){ LinearLayout item=new LinearLayout(this); item.setOrientation(LinearLayout.VERTICAL); item.setGravity(Gravity.CENTER); item.setPadding(dp(8),dp(14),dp(8),dp(14)); item.setBackground(shape(PANEL,Color.rgb(22,67,91),dp(12))); TextView i=text(icon,24,CYAN,true); i.setGravity(Gravity.CENTER); item.addView(i); TextView t=text(label,10,WHITE,true); t.setGravity(Gravity.CENTER); t.setPadding(0,dp(5),0,0); item.addView(t); LinearLayout.LayoutParams q=new LinearLayout.LayoutParams(0,-2,1); q.setMargins(dp(3),dp(4),dp(3),dp(4)); row.addView(item,q); item.setOnClickListener(v->runCommand(command)); }
    private Button button(String label,boolean primary){ Button b=new Button(this); b.setText(label); b.setTextColor(primary?Color.rgb(2,16,28):CYAN); b.setTextSize(12); b.setTypeface(Typeface.DEFAULT,Typeface.BOLD); b.setAllCaps(false); b.setBackground(shape(primary?CYAN:PANEL,primary?CYAN:Color.rgb(29,105,138),dp(12))); return b; }
    private TextView text(String s,int size,int color,boolean bold){ TextView t=new TextView(this); t.setText(s); t.setTextSize(size); t.setTextColor(color); if(bold)t.setTypeface(Typeface.DEFAULT,Typeface.BOLD); return t; }
    private GradientDrawable shape(int color,int stroke,int radius){ GradientDrawable d=new GradientDrawable(); d.setColor(color); d.setCornerRadius(radius); d.setStroke(dp(1),stroke); return d; }
    private LinearLayout.LayoutParams lp(int w,int h,int l,int t,int r,int b){ LinearLayout.LayoutParams p=new LinearLayout.LayoutParams(w,h); p.setMargins(l,t,r,b); return p; }
    private int dp(int n){return (int)(n*getResources().getDisplayMetrics().density+.5f);}
    private void listen(){ try { Intent i=new Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH); i.putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL,RecognizerIntent.LANGUAGE_MODEL_FREE_FORM); i.putExtra(RecognizerIntent.EXTRA_LANGUAGE,Locale.getDefault()); i.putExtra(RecognizerIntent.EXTRA_PROMPT,"Speak a JARVIS command"); startActivityForResult(i,SPEECH_REQUEST); } catch(Exception e){ feedback("Voice input is unavailable. Type a command instead.",false); } }
    @Override protected void onActivityResult(int requestCode,int resultCode,Intent data){ super.onActivityResult(requestCode,resultCode,data); if(requestCode==SPEECH_REQUEST&&resultCode==RESULT_OK&&data!=null){ ArrayList<String> results=data.getStringArrayListExtra(RecognizerIntent.EXTRA_RESULTS); if(results!=null&&!results.isEmpty()){commandInput.setText(results.get(0));runCommand(results.get(0));}} }
    private void runCommand(String raw){
        String input=raw==null?"":raw.trim(); if(input.isEmpty()){feedback("Type or speak a question or command first.",false);return;}
        String cmd=input.toLowerCase(Locale.ROOT);
        JarvisAccessibilityService service=JarvisAccessibilityService.getInstance();
        if(service!=null && isLocalCommand(cmd)) { boolean ok=service.executeCommand(cmd); feedback(ok?"Done. Executed: "+input:"I couldn't perform that action. Check whether the app is available and permissions are enabled.",ok); return; }
        if(!brain.isConfigured()) { feedback("I can handle basic local commands, but my AI brain isn't connected. Tap AI BRAIN SETUP to add an API key. No key is bundled with this app.",false); return; }
        sendButton.setEnabled(false); sendButton.setText("THINKING…"); status.setText("STATUS: THINKING"); status.setTextColor(CYAN); conversation.setText("JARVIS is thinking…");
        brain.ask(input,(reply,action,error)->runOnUiThread(()->{
            sendButton.setEnabled(true); sendButton.setText("ASK JARVIS   →");
            if(error!=null){feedback(error,false);return;}
            boolean actionOk=true;
            if(action!=null && !action.equals("none")) {
                JarvisAccessibilityService svc=JarvisAccessibilityService.getInstance();
                String mapped=mapAction(action);
                if(mapped==null || svc==null) actionOk=false; else actionOk=svc.executeCommand(mapped);
            }
            String finalReply=reply==null?"I couldn't create a response.":reply;
            if(action!=null && !action.equals("none")) finalReply += actionOk?"\n\nAction completed.":"\n\nI couldn't run that action. Enable JARVIS phone-control accessibility permission and try again.";
            feedback(finalReply, action==null||action.equals("none")||actionOk);
        }));
    }
    private boolean isLocalCommand(String cmd){
        return cmd.equals("home")||cmd.equals("go home")||cmd.equals("press home")||cmd.equals("back")||cmd.equals("go back")||cmd.equals("press back")||cmd.equals("notifications")||cmd.equals("open notifications")||cmd.equals("show notifications")||cmd.equals("quick settings")||cmd.equals("open quick settings")||cmd.equals("lock screen")||cmd.equals("open youtube")||cmd.equals("youtube")||cmd.equals("open gmail")||cmd.equals("gmail")||cmd.equals("open telegram")||cmd.equals("telegram")||cmd.equals("open discord")||cmd.equals("discord")||cmd.startsWith("search youtube for ")||cmd.startsWith("find youtube video ")||cmd.equals("open google")||cmd.equals("google")||cmd.equals("open chrome")||cmd.equals("chrome")||cmd.equals("open settings")||cmd.equals("settings")||cmd.startsWith("open https://")||cmd.startsWith("open http://");
    }
    private String mapAction(String action){ switch(action){case "home":return "home";case "back":return "back";case "notifications":return "notifications";case "quick_settings":return "quick settings";case "open_youtube":return "open youtube";case "open_gmail":return "open gmail";case "open_telegram":return "open telegram";case "open_discord":return "open discord";case "open_google":return "open google";case "open_chrome":return "open chrome";case "open_settings":return "open settings";default:return null;} }
    private void showBrainSetup(){
        LinearLayout box=new LinearLayout(this); box.setPadding(dp(20),dp(8),dp(20),0); box.setOrientation(LinearLayout.VERTICAL);
        EditText key=new EditText(this); key.setSingleLine(true); key.setHint("API key (stored on this phone)"); key.setInputType(129); key.setTextColor(WHITE); key.setHintTextColor(MUTED); key.setText(getSharedPreferences("jarvis_brain",MODE_PRIVATE).getString("api_key","")); box.addView(key);
        EditText model=new EditText(this); model.setSingleLine(true); model.setHint("Model ID, e.g. openrouter/free"); model.setTextColor(WHITE); model.setHintTextColor(MUTED); model.setText(brain.getModel()); box.addView(model);
        TextView note=text("Uses an OpenRouter-compatible chat endpoint. Get your own key from the provider. Free models and quotas can change; a key is not included and may not be completely free.",11,MUTED,false); note.setPadding(0,dp(8),0,0); box.addView(note);
        new android.app.AlertDialog.Builder(this).setTitle("Connect JARVIS AI Brain").setView(box).setNegativeButton("CANCEL",null).setNeutralButton("CLEAR KEY",(d,w)->{brain.saveConfig("",brain.getModel());feedback("AI key removed. Local commands still work.",true);}).setPositiveButton("SAVE",(d,w)->{brain.saveConfig(key.getText().toString(),model.getText().toString());feedback(brain.isConfigured()?"AI settings saved on this phone. Ask a question to test the connection.":"No API key saved. Local commands remain available.",brain.isConfigured());}).show();
    }
    private void feedback(String msg,boolean ok){ conversation.setText(msg); status.setText(ok?"STATUS: READY":"STATUS: NEEDS ATTENTION"); status.setTextColor(ok?CYAN:Color.rgb(255,190,105)); speak(msg); }
}
