package com.varun.jarviscontrol;

import android.content.Context;
import android.content.SharedPreferences;
import org.json.JSONArray;
import org.json.JSONObject;
import java.io.BufferedReader;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.nio.charset.StandardCharsets;

/** Part 1: configurable AI reasoning/chat layer. No API key is bundled in the app. */
public final class JarvisBrain {
    public interface Callback { void onResult(String reply, String action, String error); }
    private final Context context;
    private final SharedPreferences prefs;
    public JarvisBrain(Context c) { context=c.getApplicationContext(); prefs=context.getSharedPreferences("jarvis_brain", Context.MODE_PRIVATE); }
    public String getModel() { return prefs.getString("model", "openrouter/free"); }
    public boolean isConfigured() { return !prefs.getString("api_key", "").trim().isEmpty(); }
    public void saveConfig(String key, String model) { prefs.edit().putString("api_key", key.trim()).putString("model", model.trim().isEmpty()?"openrouter/free":model.trim()).apply(); }
    public void ask(String userText, Callback callback) {
        final String key=prefs.getString("api_key", "").trim();
        final String model=prefs.getString("model", "openrouter/free").trim();
        if(key.isEmpty()) { callback.onResult(null, null, "AI brain isn't connected yet. Tap AI SETUP and add your own API key. You can still use supported local commands."); return; }
        new Thread(() -> {
            HttpURLConnection conn=null;
            try {
                URL url=new URL("https://openrouter.ai/api/v1/chat/completions");
                conn=(HttpURLConnection)url.openConnection(); conn.setRequestMethod("POST"); conn.setConnectTimeout(20000); conn.setReadTimeout(30000); conn.setDoOutput(true);
                conn.setRequestProperty("Authorization", "Bearer "+key); conn.setRequestProperty("Content-Type", "application/json; charset=utf-8");
                JSONObject body=new JSONObject(); body.put("model", model); body.put("temperature", 0.4); body.put("max_tokens", 700);
                JSONArray messages=new JSONArray();
                JSONObject system=new JSONObject(); system.put("role","system"); system.put("content",
                    "You are JARVIS, a concise helpful Android personal assistant. Understand natural language, reason carefully, and never claim an action was completed unless the app confirms it. You may request only these supported tools: home, back, notifications, quick_settings, open_youtube, open_google, open_chrome, open_settings. Return ONLY valid JSON with keys reply and action. action must be one of none, home, back, notifications, quick_settings, open_youtube, open_google, open_chrome, open_settings. If user asks for anything else (including Gmail, Telegram, Discord, downloading videos, reading messages, sending messages, or background actions), set action to none and explain that integration is not implemented yet. Never request passwords or secrets in chat. Ask for confirmation before potentially consequential actions; currently do not execute consequential actions."); messages.put(system);
                JSONObject user=new JSONObject(); user.put("role","user"); user.put("content",userText); messages.put(user); body.put("messages",messages);
                byte[] bytes=body.toString().getBytes(StandardCharsets.UTF_8); try(OutputStream os=conn.getOutputStream()){os.write(bytes);}
                int code=conn.getResponseCode(); InputStream stream=(code>=200&&code<300)?conn.getInputStream():conn.getErrorStream();
                StringBuilder sb=new StringBuilder(); try(BufferedReader br=new BufferedReader(new InputStreamReader(stream,StandardCharsets.UTF_8))){String line;while((line=br.readLine())!=null)sb.append(line);}
                JSONObject response=new JSONObject(sb.toString());
                if(code<200||code>=300) throw new Exception("AI service returned HTTP "+code+". Check your key, model, connection, and free-tier availability.");
                String content=response.getJSONArray("choices").getJSONObject(0).getJSONObject("message").getString("content").trim();
                // Some models wrap JSON in Markdown fences; strip them defensively.
                content=content.replaceAll("^```(?:json)?\\s*", "").replaceAll("\\s*```$", "").trim();
                JSONObject answer=new JSONObject(content); String reply=answer.optString("reply","I couldn't form a reply."); String action=answer.optString("action","none");
                callback.onResult(reply, action, null);
            } catch(Exception e) { callback.onResult(null,null,"AI request failed: "+(e.getMessage()==null?"unknown error":e.getMessage())); }
            finally { if(conn!=null)conn.disconnect(); }
        }).start();
    }
}
