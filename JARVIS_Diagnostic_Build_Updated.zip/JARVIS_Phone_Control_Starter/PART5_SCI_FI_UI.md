# Part 5 — Clean Sci-Fi UI refresh

The main screen has been redesigned around a single central Canvas-drawn reactor, a prominent voice action, a clear command field, compact quick controls, connected-app shortcuts, and one activity console. It uses native Android views and a ScrollView to reduce overlap on smaller screens. The reactor is drawn in code, so no remote images or additional dependencies are required.

This is a source-level UI refresh, not a claim of verified device rendering. Test on the target phone and adjust if font scaling or device-specific insets cause issues.

## Supported app shortcuts
YouTube, Gmail, Telegram and Discord shortcuts open the corresponding web app/site through Android's URL handler. They do not read messages, download videos, or manage a Discord server.
